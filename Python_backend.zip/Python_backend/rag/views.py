from rest_framework.decorators import api_view
from rest_framework.response import Response
from openai import OpenAI
from .models import Document
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
import fitz  # PyMuPDF for PDF handling
import pandas as pd
from openai import OpenAI
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Document

client = OpenAI(api_key="Your_OPENAI_API_KEY")

def extract_text_from_pdf(pdf_path):
    """Extract text from a PDF file using PyMuPDF."""
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text("text") + "\n"
    return text

def extract_text_from_csv(csv_path):
    """Extract text from a CSV file using pandas."""
    df = pd.read_csv(csv_path, encoding='utf-8', engine='python')
    return df.to_string(index=False)

@api_view(['POST'])
def ingest_document(request):
    """Handle document ingestion for PDF, CSV, and TXT files."""
    title = request.data.get("title", "Untitled Document")
    file = request.FILES.get("file")  # Get uploaded file
    
    if not file:
        return Response({"error": "No file uploaded"}, status=400)

    # Save file temporarily
    file_path = default_storage.save(f"uploads/{file.name}", ContentFile(file.read()))
    full_path = default_storage.path(file_path)

    # Extract text based on file type
    if file.name.endswith(".pdf"):
        content = extract_text_from_pdf(full_path)
    elif file.name.endswith(".csv"):
        content = extract_text_from_csv(full_path)
    elif file.name.endswith(".txt"):
        content = file.read().decode("utf-8")
    else:
        return Response({"error": "Unsupported file format"}, status=400)

    # Generate embedding
    response = client.embeddings.create(input=content, model="text-embedding-3-small")
    
    # Save to database
    doc = Document.objects.create(title=title, content=content, embedding=response.data[0].embedding)
    
    return Response({"message": "Document stored successfully", "id": doc.id})

@api_view(['POST'])
def question_answering(request):
    question = request.data.get("question")
    documents = Document.objects.all()
    relevant_doc = max(documents, key=lambda doc: sum(a*b for a, b in zip(doc.embedding, client.Embedding.create(input=question, model="text-embedding-ada-002")['data'][0]['embedding'])))
    response = client.ChatCompletion.create(model="gpt-3.5-turbo", messages=[{"role": "system", "content": relevant_doc.content}, {"role": "user", "content": question}])
    return Response({"question": question, "answer": response['choices'][0]['message']['content']})
