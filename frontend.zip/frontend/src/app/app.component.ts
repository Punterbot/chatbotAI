import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import axios from 'axios';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  question: string = '';
  answer: string = '';
  chatHistory: { user: string, bot: string }[] = [];
  selectedFile: File | null = null;

  async askQuestion() {
    if (!this.question.trim()) return;
    
    const response = await axios.post('http://localhost:8000/qa/', { question: this.question });
    this.chatHistory.push({ user: this.question, bot: response.data.answer });
    this.question = '';
  }

  onFileChange(event: any) {
    this.selectedFile = event.target.files[0];
  }

  async uploadFile() {
    if (!this.selectedFile) return;

    const formData = new FormData();
    formData.append('file', this.selectedFile);

    await axios.post('http://localhost:8000/ingest/', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });

    alert('File uploaded successfully!');
    this.selectedFile = null;
  }
}
